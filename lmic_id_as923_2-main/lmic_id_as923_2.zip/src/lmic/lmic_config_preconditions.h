/* lmic_config_preconditions.h	Fri May 19 2017 23:58:34 tmm */

/*

Module:  lmic_config_preconditions.h

Function:
	Preconditions for LMIC configuration.

Version:
	V2.0.0	Sun Aug 06 2017 17:40:44 tmm	Edit level 1

Copyright notice:
	This file copyright (C) 2017 by

		MCCI Corporation
		3520 Krums Corners Road
		Ithaca, NY  14850

        MIT License

        Permission is hereby granted, free of charge, to any person obtaining a copy
        of this software and associated documentation files (the "Software"), to deal
        in the Software without restriction, including without limitation the rights
        to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
        copies of the Software, and to permit persons to whom the Software is
        furnished to do so, subject to the following conditions:

        The above copyright notice and this permission notice shall be included in all
        copies or substantial portions of the Software.

        THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
        IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
        FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
        AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
        LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
        OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
        SOFTWARE.

Author:
	Terry Moore, MCCI Corporation	July 2017

Revision history:
   2.0.0  Sun Aug 06 2017 17:40:44  tmm
	Module created.

*/

#ifndef _LMIC_CONFIG_PRECONDITIONS_H_
# define _LMIC_CONFIG_PRECONDITIONS_H_

// We need to be able to compile with different options without editing source.
// When building with a more advanced environment, set the following variable:
// ARDUINO_LMIC_PROJECT_CONFIG_H=my_project_config.h
//
// otherwise the lmic_project_config.h from the ../../project_config directory will be used.
#ifndef ARDUINO_LMIC_PROJECT_CONFIG_H
# define ARDUINO_LMIC_PROJECT_CONFIG_H ../../project_config/lmic_project_config.h
#endif

#define CFG_TEXT_1(x)	CFG_TEXT_2(x)
#define CFG_TEXT_2(x)	#x

// constants for comparison
#define LMIC_REGION_eu868    1
#define LMIC_REGION_us915    2
#define LMIC_REGION_cn783    3
#define LMIC_REGION_eu433    4
#define LMIC_REGION_au921    5
#define LMIC_REGION_cn490    6
#define LMIC_REGION_as923    7
#define LMIC_REGION_kr921    8
#define LMIC_REGION_in866    9

// include the file that the user is really supposed to edit. But for really strange
// ports, this can be suppressed
#ifndef ARDUINO_LMIC_PROJECT_CONFIG_H_SUPPRESS
# include CFG_TEXT_1(ARDUINO_LMIC_PROJECT_CONFIG_H)
#endif /* ARDUINO_LMIC_PROJECT_CONFIG_H_SUPPRESS */

// a mask of the supported regions
// TODO(tmm@mcci.com) consider moving this block to a central file as it's not
// user-editable.
#define LMIC_REGIONS_SUPPORTED  (                               \
                                (1 << LMIC_REGION_eu868) |      \
                                (1 << LMIC_REGION_us915) |      \
                             /* (1 << LMIC_REGION_cn783) | */   \
                             /* (1 << LMIC_REGION_eu433) | */   \
                                (1 << LMIC_REGION_au921) |      \
                             /* (1 << LMIC_REGION_cn490) | */   \
                                (1 << LMIC_REGION_as923) |      \
                             /* (1 << LMIC_REGION_kr921) | */   \
                                (1 << LMIC_REGION_in866) |      \
                                0)

//
// Our input is a -D of one of CFG_eu868, CFG_us915, CFG_as923, CFG_au915, CFG_in866
// More will be added in the the future. So at this point we create CFG_region with
// following values. These are in order of the sections in the manual. Not all of the
// below are supported yet.
//
# define CFG_LMIC_REGION_MASK   \
                        ((defined(CFG_eu868) << LMIC_REGION_eu868) | \
                         (defined(CFG_us915) << LMIC_REGION_us915) | \
                         (defined(CFG_cn783) << LMIC_REGION_cn783) | \
                         (defined(CFG_eu433) << LMIC_REGION_eu433) | \
                         (defined(CFG_au921) << LMIC_REGION_au921) | \
                         (defined(CFG_cn490) << LMIC_REGION_cn490) | \
                         (defined(CFG_as923) << LMIC_REGION_as923) | \
                         (defined(CFG_kr921) << LMIC_REGION_kr921) | \
                         (defined(CFG_in866) << LMIC_REGION_in866) | \
                         0)

// the selected region.
#define CFG_region      ((defined(CFG_eu868) * LMIC_REGION_eu868) + \
                         (defined(CFG_us915) * LMIC_REGION_us915) + \
                         (defined(CFG_cn783) * LMIC_REGION_cn783) + \
                         (defined(CFG_eu433) * LMIC_REGION_eu433) + \
                         (defined(CFG_au921) * LMIC_REGION_au921) + \
                         (defined(CFG_cn490) * LMIC_REGION_cn490) + \
                         (defined(CFG_as923) * LMIC_REGION_as923) + \
                         (defined(CFG_kr921) * LMIC_REGION_kr921) + \
                         (defined(CFG_in866) * LMIC_REGION_in866) + \
                         0)

// finally the mask of` US-like and EU-like regions
#define CFG_LMIC_EU_like_MASK   (                               \
                                (1 << LMIC_REGION_eu868) |      \
                             /* (1 << LMIC_REGION_us915) | */   \
                                (1 << LMIC_REGION_cn783) |      \
                                (1 << LMIC_REGION_eu433) |      \
                             /* (1 << LMIC_REGION_au921) | */   \
                             /* (1 << LMIC_REGION_cn490) | */   \
                                (1 << LMIC_REGION_as923) |      \
                                (1 << LMIC_REGION_kr921) |      \
                                (1 << LMIC_REGION_in866) |      \
                                0)

#define CFG_LMIC_US_like_MASK   (                               \
                             /* (1 << LMIC_REGION_eu868) | */   \
                                (1 << LMIC_REGION_us915) |      \
                             /* (1 << LMIC_REGION_cn783) | */   \
                             /* (1 << LMIC_REGION_eu433) | */   \
                                (1 << LMIC_REGION_au921) |      \
                             /* (1 << LMIC_REGION_cn490) | */   \
                             /* (1 << LMIC_REGION_as923) | */   \
                             /* (1 << LMIC_REGION_kr921) | */   \
                             /* (1 << LMIC_REGION_in866) | */   \
                                0)

#define CFG_LMIC_EU_like        (!!(CFG_LMIC_REGION_MASK & CFG_LMIC_EU_like_MASK))
#define CFG_LMIC_US_like        (!!(CFG_LMIC_REGION_MASK & CFG_LMIC_US_like_MASK))



#endif /* _LMIC_CONFIG_PRECONDITIONS_H_ */
